Bonjour,

Voici ci-joint notre diaporama ainsi que nos jupyter notebooks sur le thème du MLP (Supervised Learning) : 

Le jupyter notebook "Lab_2_Multi_Layer_Perceptron_Pyrat" contient principalement les scripts utilisés pour l'entrainement de classifiers pour Pyrat. 

Le jupyter notebook "Lab_2_Multi_Layer_Perceptron_Blobs" contient quant à lui les scripts utilisés pour le simple use case qui entraine le classifier sur des blobs pour différents paramètres. Ce dernier contient également des parties de scripts pour la prédiction de gagnants pyrat. Or ces derniers scripts sont à ignorer puisqu'ils sont incomplets. 

Pour résumer : 
prédiction Pyrat : Lab_2_Multi_Layer_Perceptron_Pyrat
prédiction blobs (simple use case) : Lab_2_Multi_Layer_Perceptron_Blobs

Cordialement, 

SAILLY Gregory